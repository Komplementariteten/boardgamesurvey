package server

import "testing"

func TestServer_WillErrorWithoutConfig(t *testing.T) {

}
