package pages

// Defaults are Default values for all Page Structs
type Defaults struct {
	Title        string
	LangShort    string
	TemplateName string
}
