package db

const AuthDbPool = "auth"
